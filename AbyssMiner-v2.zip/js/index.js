import { runEngine } from "./engine.js";
import { startGame } from "./game.js";
runEngine();
startGame();
//# sourceMappingURL=index.js.map