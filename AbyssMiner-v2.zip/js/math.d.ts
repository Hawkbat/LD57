export declare function moveAngleTowards(a: number, b: number, t: number): number;
export declare function moveVectorTowards(x1: number, y1: number, x2: number, y2: number, t: number): [number, number];
export declare function distance(x1: number, y1: number, x2: number, y2: number): number;
