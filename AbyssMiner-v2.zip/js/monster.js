import { Entity } from "./entity.js";
export class Monster extends Entity {
    x = 0;
    y = 0;
}
//# sourceMappingURL=monster.js.map