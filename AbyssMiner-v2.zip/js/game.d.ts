export declare function startGame(): void;
