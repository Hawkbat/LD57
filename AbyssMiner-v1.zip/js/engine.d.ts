export declare function getAverageFPS(): number;
export declare function runEngine(): void;
